package com.example.project;

public class user {

    public String email;
    public String password;


    public user(String email, String password) {
        this.email = email;
        this.password = password;
    }


}
